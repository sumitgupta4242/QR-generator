import React from "react";
import QR from "./components/QR"
import './App.css';

function App() {
  return (
    <div className="App">
      <QR/>
    </div>
  );
}

export default App;
