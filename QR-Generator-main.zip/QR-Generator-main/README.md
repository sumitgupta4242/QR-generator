# QR Generator

## Developed in React and using React-qr-code libraries

QR Generator created with react

- **React-qr-code: [react-qr-code](https://www.npmjs.com/package/react-qr-code)**

  Install react-qr-code:

  ```bash
  $ yarn add react-qr-code
  ```

- **Preview**

  Page

  ![preview img](/preview.png)
